
# Spooky Company
Haunt your crewmates when you die. If you speak loudly enough while spectating, the person you are watching will hear a ghost noise.

Still to do:
- Make min microphone amplitude for ghost event configurable per user

Thanks to my go-to Lethal crew.
Special thanks to Luke, Nick and especially Jonathan.