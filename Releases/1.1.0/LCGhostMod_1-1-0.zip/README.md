# Spooky Company
Haunt your crewmates when you die. If you speak loudly enough while spectating, the person you are watching will hear a spooky ghost noise, and so will anyone else spectating.

## Configs

The following values are configurable in Thunderstore / the BepInEx config file:
- *Microphone Amp Threshold* - This is the threshold amplitude for your microphone input to trigger a ghost event. Adjust it depending on how sensitive your mic is.
- *Min/Max Cooldown Time* - Time between ghost events triggered by you.
- *Randomize Pitch Range* - How much ghost SFX pitch that you hear will be randomized.
- *Randomize Volume Range* - How much ghost SFX volume that you hear will be randomized.

## Thanks

Thanks to my go-to Lethal crew. Special thanks to Luke, Nick and especially Jonathan.